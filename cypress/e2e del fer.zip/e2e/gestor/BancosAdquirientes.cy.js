describe('Formulario de Bancos Adquirientes', () => {

    it('Bancos adquirientes happy path', () => {

        const Link = 'https://auth-qa.conceptopagos.com/sso/realms/Gestor/protocol/openid-connect/auth?client_id=Client_Gestor&redirect_uri=https%3A%2F%2Fgestor-qa.conceptopagos.com%2Fmerchants%2Fadd-client&state=415ef774-b0f9-4624-8368-34320b7a6c44&response_mode=fragment&response_type=code&scope=openid&nonce=8cc1643f-298d-4d93-9e1e-b782624bd579&code_challenge=tMHFzgAs9rHOQcMxamv8jW8CCuS6vPgXQmWtniQgErg&code_challenge_method=S256';

        cy.visit(Link);

        cy.get('input[name="username"]').type('feryaar08@gmail.com', { delay: 100 });

        cy.get('input[name="password"]').type('Desarrollo10*', { delay: 100 });

        cy.get('#kc-login').click();

        cy.pause()

        cy.get('#kc-login').click();

        cy.wait(4000)

        cy.origin('https://gestor-qa.conceptopagos.com', () => {

            cy.contains('mat-label', 'Operacion')
                .parents('div.mat-tree-node')
                .find('button')
                .click();

            cy.contains('mat-label', 'Bancos adquirentes').click();

            cy.get('button.mat-mdc-unelevated-button.mat-unthemed').click();

        });

    });
})